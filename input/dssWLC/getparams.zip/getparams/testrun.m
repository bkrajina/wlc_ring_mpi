% --------
%% test all the code for dssWLC calculations
% ---------

% tabulate coupling coefficients for spherical harmonics
% only have to do this once and then save results
Ycouple = getYcouple(LMAX,'YcoupleSave.mat')